# Face Detection using OpenCV

## Overview
This project implements real-time face detection using OpenCV's Haar Cascade Classifier. The script captures video from the default webcam, detects faces, and draws bounding boxes around detected faces.

## Features
- Real-time face detection using OpenCV
- Uses Haar Cascade for face recognition
- Displays live webcam feed with detected faces
- Press 'q' to exit the application

## Installation

1. Clone the repository:
   ```sh
   git clone https://github.com/your-username/face-detection-opencv.git
   cd face-detection-opencv
   ```
2. Install required dependencies:
   ```sh
   pip install -r requirements.txt
   ```

## Usage

1. Run the script:
   ```sh
   python jagadeeshcyfuture.py
   ```
2. The webcam window will open, detecting faces in real-time.
3. Press 'q' to exit the application.

## Repository Structure
```
/Face-Detection-OpenCV
│-- README.md
│-- requirements.txt
│-- jagadeeshcyfuture.py
│-- haarcascades/
│   ├── haarcascade_frontalface_default.xml
│-- images/ (Optional: Sample detected face images)
```

## Dependencies
- OpenCV
- NumPy

## Notes
- Ensure `haarcascade_frontalface_default.xml` is available in the `haarcascades/` directory or specify the correct path in the script.
- Adjust `detectMultiScale()` parameters for better accuracy.

## License
This project is licensed under the MIT License.

## Author
[Jagadeesh]
